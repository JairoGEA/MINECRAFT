Define custom placeholders in file 'placeholders.yml'.
Define custom format rules in file 'rules.yml'.